# User-Behavior-Analysis
- Network Security Project

## Train
- It will try to train the model and test the model
	- The directory is **test**
	- Train directory is **<./Train/Person_i>**
```
python3 main.py -t <Test_directory>
```

## Test
- Test the model
```
python3 main.py <Test_directory>
```
- Example
```
python3 main.py ./Example_Test/
```

## Model
### Feature
- Data name
- logonID
- Image